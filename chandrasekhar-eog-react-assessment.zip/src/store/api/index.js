import findLocationByLatLng from "./findLocationByLatLng";
import findWeatherbyId from "./findWeatherById";
import findDroneLocation from "./findDroneLocation";

export default {
  findLocationByLatLng,
  findWeatherbyId,
  findDroneLocation
};
